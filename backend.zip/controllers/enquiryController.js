import { Enquiry } from '../models/enquiryModal.js';

export async function createEnquiry(req, res) {
  try {
    const enquiry = await Enquiry.create(req.body);
    res.status(201).json({ message: 'Enquiry created successfully', enquiry });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
}

export async function getAllEnquiries(req, res) {
  try {
    const enquiries = await Enquiry.find({},'fullName mobile location email message -_id');
    res.status(200).json(enquiries);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
}