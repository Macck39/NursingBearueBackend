import { Request } from '../models/requestModal.js';

export async function createRequest(req, res) {
  try {
    const callback = await Request.create(req.body);
    res.status(201).json({ message: 'Callback request created successfully', callback });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
}

export async function getAllRequest(req, res) {
  try {
    const callbacks = await Request.find({},'fullName mobile location preferredTime -_id');
    res.status(200).json(callbacks);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
}