import mongoose from "mongoose";

const requestSchema = mongoose.Schema({
  fullName: { type: String, required: true },
  mobile: { type: String, required: true },
  location: { type: String, required: true },
  preferredTime: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
});

export const Request= mongoose.model('Request', requestSchema);